function [best_pos,CNVG]=IJAYA(SearchAgents_no,MaxFES,lb,ub,dim,fobj)
%IJAYA

%set parameters
if numel(lb)==1, lb=lb*ones(1,dim); ub=ub*ones(1,dim); end
  t = 0;
    CNVG=[];
Convergence_curve=zeros(1,MaxFES);
fitcount=0;
best_score = inf;
best_pos = zeros(1,dim);

%initialization 
Positions=initialization(SearchAgents_no,dim,ub,lb);

rand('seed', sum(100 * clock)); 

for i=1:size(Positions,1)
    fitness(i,:)=fobj(Positions(i,:));
    if fitness(i,:) < best_score
        best_score = fitness(i,:);
        best_pos = Positions(i,:);
    end
   
end
FES=SearchAgents_no;

z=rand();

while FES<MaxFES
    
    'IJAYA'
    FES
    
    [~,index]=sort(fitness);
    if fitness(index(1),:) < best_score
        best_score = fitness(index(1),:);
        best_pos = Positions(index(1),:);
    end
    worst_score=fitness(index(end),:);
    worst_pos=Positions(index(end),:);
    
    if worst_score==0
        w=1;
    else
        w=abs(best_score/worst_score)^2;
    end
    
    for i=1:SearchAgents_no
        if i~=index(1)
            if rand<rand
                for j=1:size(Positions,2)
                    X(j)=Positions(i,j)+rand*(best_pos(j)-abs(Positions(i,j)))-w*rand*(worst_pos(j)-abs(Positions(i,j)));
                end
            else
                num=randperm(SearchAgents_no,2);
                while num(1)==i || num(2)==i
                    num=randperm(SearchAgents_no,2);
                end
                
                if fitness(num(1),:)<fitness(num(2),:)
                    X=Positions(i,:)+rand(1,dim).*(Positions(num(1),:)-Positions(num(2),:));
                else
                    X=Positions(i,:)-rand(1,dim).*(Positions(num(1),:)-Positions(num(2),:));
                end
            end
        else
            
            z=4*z*(1-z);
            for j=1:size(Positions,2)
                X(j)=best_pos(j)+(2*z-1)*rand;
            end
        end
        
         % boundary control
        for j=1:size(X,2)
            if X(j)<lb(j)
                X(j)=lb(j);
            elseif X(j)>ub(j)
                X(j)=ub(j);
            end
        end
        
        Xfitness=fobj(X);
        FES=FES+1;
        if Xfitness<fitness(i,:)
            fitness(i,:)=Xfitness;
            Positions(i,:)=X;
        end
        if Xfitness < best_score
            best_score = Xfitness;
            best_pos = X;
        end
           
    end
      t = t + 1;
    CNVG(1,t) = best_score;
end
[Min_score,k]=min(fitness);
if Min_score <best_score
    best_score = Min_score;
    best_pos = Positions(k(1),:);
end
end

