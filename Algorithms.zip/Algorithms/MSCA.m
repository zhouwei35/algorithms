% Nenavath, H. and R. K. Jatoth (2018). "Hybridizing sine cosine algorithm with differential evolution for global optimization and object tracking." Applied Soft Computing Journal 62: 1019-1043.

function [Destination_position, Convergence_curve]=MSCA(N,MaxFEs,lb,ub,dim,fobj)
tic
fes = 0;
X=initialization(N,dim,ub,lb);
Destination_position=zeros(1,dim);
Destination_fitness=zeros(1,dim);
for i=1:size(X,1)
       Destination_fitness(1,i)=fobj(X(i,:));
       fes=fes+1;
end
 [Destination_fitness_sorted n]=sort(Destination_fitness);
 sorted_X=X(n,:);      

t=1; 
while fes<=MaxFEs
    if t>1
        [Destination_fitness,fes]=get_fitness(X,fobj,fes);
        double_population=[X;sorted_X];
        double_fitness=[Destination_fitness Destination_fitness_sorted];
        
        [double_fitness_sorted n]=sort(double_fitness);
        double_sorted_population=double_population(n,:);
        
        Destination_fitness_sorted=double_fitness_sorted(1:N);
        sorted_X=double_sorted_population(1:N,:);
    end
    Destination_position_score=Destination_fitness_sorted(1);
    Destination_position=sorted_X(1,:);
   
     
    a = 2;
    r1=a-fes*((a)/MaxFEs); % r1 decreases linearly from a to 0

    for i=1:size(X,1) % in i-th solution
        for j=1:size(X,2) % in j-th dimension
       
            r2=(2*pi)*rand();
            r3=1;
            r4=rand();

            % Eq. (3.3)
            if r4<0.5
                % Eq. (3.1)
                X(i,j)= X(i,j)+(r1*sin(r2)*abs(r3*sorted_X(i,j)-X(i,j)));
            else
                % Eq. (3.2)
                X(i,j)= X(i,j)+(r1*cos(r2)*abs(r3*sorted_X(i,j)-X(i,j)));
            end  
        end
    end
    
    
%        X1=SSA_SCA(X,Destination_position,fes,MaxFEs,ub,lb);%   
%        X1=SCA_MVO(X,Destination_fitness_sorted,sorted_X,Destination_position,lb,ub,fes,MaxFEs);
%          X1=MF(X,sorted_X,fes,MaxFEs);
       X1=SCA_MVO(X,Destination_fitness_sorted,sorted_X,Destination_position,lb,ub,fes,MaxFEs);
%        X3=OBL(X);
%        X2=SCA_ALO(X,Destination_position,sorted_X,Destination_position_score,fes,MaxFEs,lb,ub);
%        X3=SCA_DE(X,lb,ub);
%      X=WO(X,fes,MaxFEs,N,Destination_position);
%      X=GW(X,fes,MaxFEs,sorted_X);
%      X=FA_SCA(X,sorted_X,Destination_fitness_sorted,lb,ub);
%      X=F(X,ub,lb,fes);
%      X=Cross_I(X,lb,ub);
%      X=Criss_I(X);
%      X=Lenvy(X,1);
%      X=CG(X,0.2,fes,MaxFEs);
%        X3=Gauss(X,1);
%      X=Cauchy(X,1);
%     
       X=Overout(X1,lb,ub);
%      X2=Overout(X2,lb,ub);
%      X3=Overout(X3,lb,ub);
%     [X,fes]=Choose_Best_Three(X1,X2,X3,fobj,fes);
%     
%     delta=0.2;
%    X3=CG(X,delta,fes,MaxFEs);
%    X3=OBL(X)
    Convergence_curve(t)=Destination_position_score;
%     YYY=Destination_position_score
    t=t+1;
end
toc
end

function [Y,fes]=get_fitness(X,fobj,fes)
y=zeros(1,size(X,1));
for i=1:size(X,1)
    y(1,i)=fobj(X(i,:));
    fes=fes+1;
end
Y=y;
end  %��Ӧ�����



function X=SSA_SCA(X,Destination_position,fes,MaxFEs,ub,lb)
 c1 = 2*exp(-(4*fes/MaxFEs)^2); % Eq. (3.2) in the paper
 N=size(X,1);
 dim=size(X,2);
ub=ones(dim,1).*ub';
lb=ones(dim,1).*lb';
for i=1:size(X,1)
        
        X= X';
        
        if i<=N/2
            for j=1:1:dim
                c2=rand();
                c3=rand();
                %%%%%%%%%%%%% % Eq. (3.1) in the paper %%%%%%%%%%%%%%
                if c3<0.5 
                    X(j,i)=Destination_position(j)+c1*((ub(j)-lb(j))*c2+lb(j));
                else
                    X(j,i)=Destination_position(j)-c1*((ub(j)-lb(j))*c2+lb(j));
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end
            
        elseif i>N/2 && i<N+1
            point1=X(:,i-1);
            point2=X(:,i);
            
            X(:,i)=(point2+point1)/2; % % Eq. (3.4) in the paper
        end
        
        X= X';
end
end  %SSA�㷨���²���

function X=OBL(X0)
m=size(X0,1);
n=size(X0,2);
for i=1:m
   for j=1:n
        x_min(j)=min(X0(:,j));
        x_max(j)=max(X0(:,j));
        x_ave(j)=x_max(j)+x_min(j);
        X1(i,j)=x_ave(j)-X0(i,j);
   end
   X1(i,:)=X1(1,:)*(1+randn);
end
X=X1;
end %����ѧϰ����

function X=Overout(X,lb,ub)
    for i=1:size(X,1)     
        % Check if solutions go outside the search spaceand bring them back
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    end
end %���޴���

function [X,fes]=Choose_Best_Three(X1,X2,X3,fobj,fes)
n=size(X1,1);
for i=1:n
   
    y_X1=fobj(X1(i,:));
    y_X2=fobj(X2(i,:));
    y_X3=fobj(X3(i,:));
    y_col=[y_X1,y_X2,y_X3];
    [~,k]=min(y_col);
    fes=fes+3;
    switch k
        case 1
            X1(i,:)=X1(i,:);
        case 2
            X1(i,:)=X2(i,:);
        case 3
            X1(i,:)=X3(i,:);
    end
end
X=X1;                
end  %�����ۺ�����


